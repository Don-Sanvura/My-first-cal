const display = document.getElementById('display');
const buttons = document.querySelector('.buttons');

let expr = '';

function updateDisplay() {
  display.value = expr || '0';
}

function pushValue(v) {
  expr += v;
  updateDisplay();
}

function backspace() {
  expr = expr.slice(0, -1);
  updateDisplay();
}

function clearAll() {
  expr = '';
  updateDisplay();
}

function toggleParen() {
  // simple toggle: add '(' if last char is operator or empty, else add ')'
  const last = expr.slice(-1);
  if (!last || /[+\-×÷*/(]/.test(last)) pushValue('(');
  else pushValue(')');
}

function calculate() {
  if (!expr) return;
  // convert symbols to JS operators
  const sanitized = expr.replace(/×/g, '*').replace(/÷/g, '/');
  try {
    // Use Function to evaluate expression (acceptable for local apps; don't eval untrusted input)
    const result = Function('"use strict"; return (' + sanitized + ')')();
    expr = String(result);
  } catch (e) {
    expr = 'Error';
  }
  updateDisplay();
}

buttons.addEventListener('click', (e) => {
  const btn = e.target.closest('button');
  if (!btn) return;
  const val = btn.getAttribute('data-value');
  const action = btn.getAttribute('data-action');
  if (val) {
    pushValue(val);
  } else if (action) {
    if (action === 'clear') clearAll();
    if (action === 'back') backspace();
    if (action === 'paren') toggleParen();
    if (action === 'equals') calculate();
  }
});

// keyboard support
window.addEventListener('keydown', (e) => {
  if (e.key >= '0' && e.key <= '9') pushValue(e.key);
  else if (e.key === '.') pushValue('.');
  else if (e.key === '+' || e.key === '-' || e.key === '*' || e.key === '/') pushValue(e.key);
  else if (e.key === 'Enter') { e.preventDefault(); calculate(); }
  else if (e.key === 'Backspace') backspace();
  else if (e.key === 'Escape') clearAll();
  updateDisplay();
});

updateDisplay();